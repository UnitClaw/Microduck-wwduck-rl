"""One identity shared by the R17 installer and console."""
BUILD = '1fa8438-feetech-ft6-control.40'
CONSOLE_VERSION = '1.0.163'
OFFICIAL_VERSION = '0.15.1'
